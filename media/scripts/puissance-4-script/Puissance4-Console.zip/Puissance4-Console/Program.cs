﻿/*
    ETML 
    Auteur : Okkes Erdem Kose
    Date : 04.11.2024
    Description : Puissance 4 en choisissant le nombre de lignes et de collones
*/

using System;

namespace puissance4_Kose
{
    internal class Program
    {
        // Position left 
        const int LEFT = 8;

        // Pions des joueurs pour être déclaré partout, avec leur couleurs
        static char PlayerIcon1 = '█'; // ASCII 219
        static ConsoleColor PlayerColor1 = ConsoleColor.Cyan;

        static char PlayerIcon2 = '█'; // ASCII 219
        static ConsoleColor PlayerColor2 = ConsoleColor.Blue;

        // Les tours, si pair ou impar, et pour le nombre de coups en fin de jeu
        static int turn = 2;

        // Icône du joueur en fonction du tour actuel
        static bool PlyCol;

        // Etat si en jeu ou pas
        static bool inGame = true;


        static void Main(string[] args)
        {
            // Constantes pour les valeurs minimales et maximales
            const int MIN_LINEVAL = 5;
            const int MAX_LINEVAL = 13;
            const int MIN_COLVAL = 6;
            const int MAX_COLVAL = 16;
            // Constante pour l'ecart entre chaque pion
            const int CHANGECOORD = 4;

            // Dimensions de la fenetre
            const int DIMX = 130;
            const int DIMY = 39;

            // Délaration en entier des valeurs
            int lineVal;
            int colVal;

            // Positions par défaut des positions
            int charLeft = 10;
            int charTop = 6;


            // Taille de la fenêtre
            Console.SetWindowSize(DIMX, DIMY);

            // Titre de la console
            Console.Title = "Puissance 4";

            do
            {
                // Remettre la couleur de l'icône du joueur 1
                PlyCol = false;

                // Titre dans le jeu
                ShowTitle();

                // Affichage du curseur
                Console.CursorVisible = true;

                // Demandes des valeurs pour faire le plateau
                lineVal = GetUserValue("lignes", MIN_LINEVAL, MAX_LINEVAL);
                colVal = GetUserValue("colonnes", MIN_COLVAL, MAX_COLVAL);

                // Cacher le curseur, clear la console, puis afficher le titre du jeu
                Console.CursorVisible = false;
                Console.Clear();
                ShowTitle();

                // Création du tableau de jeu avec le nombre de lignes et de colonnes définis par l'utilisateur
                int[,] gameTable = new int[lineVal, colVal];


                // Affiche la table de navigation du plateau de jeu
                NavigationTable(colVal);

                // Affiche le plateau de jeu avec les jetons placés
                GameTable(lineVal, colVal, gameTable);

                // Affiche l'aide du jeu et les instructions
                HelpTable(colVal);

                // Gère le mouvement du joueur et le placement des jetons
                MoveChar(charLeft, charTop, CHANGECOORD, colVal, lineVal, gameTable);

            } while (inGame);

        }

        /// <summary>
        /// Affiche le titre et les informations du jeu, avec l'auteur
        /// </summary>
        static void ShowTitle()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\t╔════════════════════════════════════════╗");
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.Write("\t║    ");
            Console.ResetColor();
            Console.Write("Bienvenue dans le jeu Puissance 4");
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("   ║");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("\t║      ");
            Console.ResetColor();
            Console.Write("Réalisé par Okkes Erdem Kose");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("      ║");
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("\t╚════════════════════════════════════════╝\n");

            Console.ResetColor();
        }



        /// <summary>
        /// Demande la valeur de l'utilisateur pour quelque chose, avec des restrictions
        /// </summary>
        /// <param name="forWhat">Pour quoi</param>
        /// <param name="minValue">Valeur minimale</param>
        /// <param name="maxValue">Valeur maximale</param>
        /// <returns>La valeur de l'utilisateur en entier</returns>
        static int GetUserValue(string forWhat, int minValue, int maxValue)
        {
            // Déclaration de la valeur de base
            int usrValue;
            bool isOk = false;

            // Proposition des valeurs
            Console.Write("\nMerci d'entrer le nombre de ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(forWhat);
            Console.ResetColor();
            Console.Write("La valeur doit être plus grande que ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write($"{minValue} ");
            Console.ResetColor();
            Console.Write("et plus petite que ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"{maxValue} ");
            Console.ResetColor();

            do
            {
                // Demande à l'utilisateur d'entrer une valeur
                Console.Write("Votre valeur : ");

                // Change la couleur du texte en cyan
                Console.ForegroundColor = ConsoleColor.Cyan;

                // Lit la valeur entrée par l'utilisateur
                string input = Console.ReadLine();

                // Réinitialise la couleur du texte
                Console.ResetColor();

                // Vérifie si l'entrée est un entier dans les limites spécifiées
                if (int.TryParse(input, out usrValue) && usrValue > minValue && usrValue < maxValue)
                {
                    // Indique que la valeur est correcte
                    isOk = true;
                }
                else
                {
                    // Informe l'utilisateur que la valeur est en dehors des limites
                    Console.WriteLine($"\nVotre valeur n'est pas dans les limites fixées >{minValue} et <{maxValue}, Merci de réessayer !\n");
                }
            } while (!isOk);

            // Retourne la valeur valide
            return usrValue;
        }

        /// <summary>
        /// Affiche le plateau de navigation
        /// </summary>
        /// <param name="colValue">Valeur de la colonne</param>
        static void NavigationTable(int colValue)
        {
            // Affiche la ligne supérieure du plateau
            Console.Write("\t╔═");
            for (int i = 1; i < colValue; i++)
            {
                Console.Write("══╦═");
            }
            Console.WriteLine("══╗");

            // Affiche la ligne vide des cases
            Console.Write("\t║");
            for (int i = 0; i < colValue; i++)
            {
                // Affiche un espace pour chaque case
                Console.Write("   ║");
            }
            Console.WriteLine();

            // Affiche la ligne inférieure du plateau
            Console.Write("\t╚═");
            for (int i = 1; i < colValue; i++)
            {
                // Affiche les séparateurs des colonnes
                Console.Write("══╩═");
            }
            Console.WriteLine("══╝");
        }

        /// <summary>
        /// Afficher les pions des joueurs
        /// </summary>
        /// <param name="icon">Pion du joueur </param>
        /// <param name="posLeft">Position à gauche</param>
        /// <param name="posTop">Position top</param>
        /// <param name="color">Couleur du joueur</param>
        static void ShowChar(char icon, int posLeft, int posTop, ConsoleColor color)
        {
            // Definis la position du curseur sur la console
            Console.SetCursorPosition(posLeft, posTop);

            // Change la couleur du texte
            Console.ForegroundColor = color;

            // Affiche l'icone à la position defini
            Console.Write(icon);

            // Réintialise la couleur du texte
            Console.ResetColor();

        }

        /// <summary>
        /// Affiche le mode d'utilisation
        /// </summary>
        /// <param name="colValue">Valeur de la colonne</param>
        static void HelpTable(int colValue)
        {
            // Définit la position du curseur pour afficher "Mode d'utilisation"
            Console.SetCursorPosition((colValue + 4) * 4, 5);
            Console.WriteLine("Mode d'utilisation");

            // Affiche une ligne de séparation sous le titre
            Console.SetCursorPosition((colValue + 4) * 4, 6);
            Console.WriteLine("──────────────────");

            // Affiche l'instruction pour les déplacement
            Console.SetCursorPosition((colValue + 5) * 4, 7);
            Console.Write("Déplacements");

            // Affiche les touches pour les déplacements
            Console.SetCursorPosition(((colValue + 5) * 4) + 17, 7);
            Console.WriteLine("Touches directionnelles");

            // Affiche l'instruction pour le tir
            Console.SetCursorPosition((colValue + 5) * 4, 8);
            Console.Write("Tir");
            // Affiche les touches pour tirer
            Console.SetCursorPosition(((colValue + 5) * 4) + 11, 8);
            Console.WriteLine("\t Spacebar ou Enter");

            // Affiche l'instruction pour quitter
            Console.SetCursorPosition((colValue + 5) * 4, 9);
            Console.Write("Quitter");
            // Affiche la touche pour quitter
            Console.SetCursorPosition(((colValue + 5) * 4) + 11, 9);
            Console.WriteLine("\t Escape");

            // Affiche les informations du joueur 1
            Console.SetCursorPosition((colValue + 5) * 4, 11);
            Console.ForegroundColor = PlayerColor1;
            Console.Write($"Joueur 1: {PlayerIcon1}");

            // Affiche les informations du joueur 2
            Console.SetCursorPosition(((colValue + 5) * 4) + 11, 11);
            Console.ForegroundColor = PlayerColor2;
            Console.WriteLine($"\t Joueur 2: {PlayerIcon2}");

            // Réinitialise la couleur du texte
            Console.ResetColor();

        }

        /// <summary>
        /// Bouge le pion du joueur, et change la couleur en fonction du joueur
        /// </summary>
        /// <param name="posLeft">Position gauche</param>
        /// <param name="posTop">Position top</param>
        /// <param name="changeCoord">Chiffre, l'écart entre chaque case</param>
        /// <param name="colValue">Valeur de la colonne</param>
        /// <param name="lineValue">Valeur de la ligne</param>
        /// <param name="gameTable">Tableau en 2 dimension, le plateau pour poser les pions</param>
        static void MoveChar(int posLeft, int posTop, int changeCoord, int colValue, int lineValue, int[,] gameTable)
        {
            // Affiche l'icône du joueur 1 à la position spécifiée
            ShowChar(PlayerIcon1, posLeft, posTop, PlayerColor1);

            // Définit la couleur du personnage en fonction du tour
            SetCharColor(turn);

            // Boucle principale pour gérer les actions du joueur
            while (true)
            {
                // Lis la touche pressé par l'utilisateur sans l'afficher
                var keyInfo = Console.ReadKey(true);

                // Efface l'icône actuel à la position spécifiée
                Console.SetCursorPosition(posLeft, posTop);
                Console.Write(' ');

                // Si l'utilisateur appuie sur Échap,ca quitte ou redémarre le jeu
                if (keyInfo.Key == ConsoleKey.Escape)
                {
                    QuitOrRestart(colValue, lineValue);
                    break;
                }
                // Déplace le pion vers la droite
                else if (keyInfo.Key == ConsoleKey.RightArrow)
                {
                    posLeft += changeCoord;
                }
                // Déplace le pion vers la gauche
                else if (keyInfo.Key == ConsoleKey.LeftArrow)
                {
                    posLeft -= changeCoord;
                }

                // Gère l'action de tir lorsque Entrée ou la barre d'espace est pressée
                else if (keyInfo.Key == ConsoleKey.Enter || keyInfo.Key == ConsoleKey.Spacebar)
                {

                    // Calcule la colonne où le pion doit tomber
                    int col = (posLeft - 10) / changeCoord;

                    // Recherche la première ligne vide dans la colonne
                    for (int row = lineValue - 1; row >= 0; row--)
                    {
                        if (gameTable[row, col] == 0)
                        {
                            PlyCol = !PlyCol;

                            // Place le jeton du joueur dans la case
                            gameTable[row, col] = turn % 2 == 0 ? 1 : 2;
                            Console.SetCursorPosition(posLeft, 10 + row * 2);
                            Console.Write(turn % 2 == 0 ? PlayerIcon2 : PlayerIcon1);

                            int player = turn % 2 == 0 ? 1 : 2;


                            if (CheckWinner(gameTable, row, col, player, lineValue, colValue))
                            {

                                // Positionne le texte à une position
                                Console.SetCursorPosition(LEFT, 5 + (lineValue + 1) * 2 + 4);

                                Console.ResetColor();
                                Console.Write($"Bravo ! ");
                                Console.ForegroundColor = player == 1 ? PlayerColor1 : PlayerColor2;
                                Console.Write($"joueur {player} ");
                                Console.ResetColor();
                                Console.Write($"Vous avez gagné en : ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.Write($"{turn-1}");
                                Console.ResetColor();
                                Console.WriteLine($" coups");



                                QuitOrRestart(colValue, lineValue);

                                Console.ResetColor();
                                return;
                            }

                            if ((lineValue * colValue) + 1 == turn)
                            {
                                // Positionne le texte à une position
                                Console.SetCursorPosition(LEFT, 5 + (lineValue + 1) * 2 + 4);

                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Match Nul ! ");
                                Console.ResetColor();
                                QuitOrRestart(colValue, lineValue);

                                return;
                            }

                            turn++;
                            break;
                        }
                    }
                }

                // Remet la position à gauche si elle dépasse la largeur du plateau
                if (posLeft >= colValue * changeCoord + 10)
                    posLeft = 10;

                // Remet la position à droite si elle est trop à gauche
                if (posLeft < 10)
                    posLeft = colValue * changeCoord + 10 - changeCoord;

                // Affiche l'icône du joueur en fonction du tour actuel
                if (PlyCol)
                    ShowChar(PlayerIcon2, posLeft, posTop, PlayerColor2);
                else
                    ShowChar(PlayerIcon1, posLeft, posTop, PlayerColor1);

                // Définit la couleur du personnage pour le tour suivant
                SetCharColor(turn);
            }
        }

        /// <summary>
        /// Vérifie le gagnant 
        /// </summary>
        /// <param name="gameTable">Un tableau qui représent le plateau de jeu</param>
        /// <param name="row">Lignes du tableau</param>
        /// <param name="col">Colonne du tableau</param>
        /// <param name="player">Le joueur</param>
        /// <param name="lineVal">Valeur de la ligne</param>
        /// <param name="colVal">Valeu de la colonne</param>
        /// <returns>Retourne un booléen pour dire si il gagné ou pas</returns>
        static bool CheckWinner(int[,] gameTable, int row, int col, int player, int lineVal, int colVal)
        {
            // Vérification horizontale
            for (int i = Math.Max(0, col - 3); i <= Math.Min(colVal - 4, col); i++)  // Boucle for de vérification de 4 cases consécutives dans la ligne
            {
                // Vérification si les 4 cases dans la ligne sont les mêmes pions du player
                if (gameTable[row, i] == player &&  // Vérifie si la case actuelle (i) contient le pion du joueur
                    gameTable[row, i + 1] == player &&  // Vérifie si la case (i+1) contient aussi le pion du joueur
                    gameTable[row, i + 2] == player &&  // Vérifie si la case (i+2) contient aussi le pion du joueur
                    gameTable[row, i + 3] == player)    // Vérifie si la case (i+3) contient aussi le pion du joueur
                {
                    return true;  // Si les 4 cases sont correctes, ça retourne true, ce qui fait gagner le joueur
                }
            }

            // Vérification verticale
            for (int i = Math.Max(0, row - 3); i <= Math.Min(lineVal - 4, row); i++)  // Boucle for de vérification de 4 cases consécutives dans la colonne
            {
                // Vérification si les 4 cases dans la colonne sont les mêmes pions du player
                if (gameTable[i, col] == player &&  // Vérifie si la case actuelle (i) dans la colonne contient le pion du joueur
                    gameTable[i + 1, col] == player &&  // Vérifie si la case suivante (i+1) dans la colonne contient aussi le pion du joueur
                    gameTable[i + 2, col] == player &&  // Vérifie la case suivante (i+2)
                    gameTable[i + 3, col] == player)    // Vérifie la case suivante (i+3)
                {
                    return true;  // Si les 4 cases sont correctes, ça retourne true, ce qui fait gagner le joueur
                }
            }

            // Vérification diagonale descendant de gauche à droite
            for (int i = Math.Max(0, row - 3), j = Math.Max(0, col - 3); i <= Math.Min(lineVal - 4, row) && j <= Math.Min(colVal - 4, col); i++, j++)  // Boucle for de vérification de 4 cases dans une diagonale descendante de gauche à droite
            {
                // Vérification si les 4 cases diagonales sont les mêmes pions du player
                if (gameTable[i, j] == player &&  // Vérifie la première case de la diagonale
                    gameTable[i + 1, j + 1] == player &&  // Vérifie la deuxième case de la diagonale
                    gameTable[i + 2, j + 2] == player &&  // Vérifie la troisième case de la diagonale
                    gameTable[i + 3, j + 3] == player)    // Vérifie la quatrième case de la diagonale
                {
                    return true;  // Si les 4 cases sont correctes, ça retourne true, ce qui fait gagner le joueur
                }
            }

            // Vérification diagonale descendant de droite à gauche
            for (int i = Math.Min(lineVal - 1, row + 3), j = Math.Max(0, col - 3); i >= Math.Max(3, row) && j <= Math.Min(colVal - 4, col); i--, j++)  // Boucle for de vérification de 4 cases dans une diagonale descendant de droite à gauche
            {
                // Vérification si les 4 cases diagonales sont les mêmes pions du player
                if (gameTable[i, j] == player &&  // Vérifie la première case de la diagonale
                    gameTable[i - 1, j + 1] == player &&  // Vérifie la deuxième case de la diagonale
                    gameTable[i - 2, j + 2] == player &&  // Vérifie la troisième case de la diagonale
                    gameTable[i - 3, j + 3] == player)    // Vérifie la quatrième case de la diagonale
                {
                    return true;  // Si les 4 cases sont correctes, ça retourne true, ce qui fait gagner le joueur
                }
            }



            return false;
        }



        /// <summary>
        /// Définit la couleur du personnage en fonction du tour
        /// </summary>
        /// <param name="tour">Le numéro du tour actuel</param>
        static void SetCharColor(int tour)
        {
            // Si le tour est pair, utilise la couleur du joueur 1
            if (tour % 2 == 0)
            {
                Console.ForegroundColor = PlayerColor1;
            }
            // Si le tour est impair, utilise la couleur du joueur 2
            else
            {
                Console.ForegroundColor = PlayerColor2;
            }
        }


        /// <summary>
        /// Plateau de jeu
        /// </summary>
        /// <param name="lineValue">Valeur des ligne</param>
        /// <param name="colValue">Valeur dse colonnes</param>
        /// <param name="gameTable">Dimensions du tableau 2 dimensions</param>
        static void GameTable(int lineValue, int colValue, int[,] gameTable)
        {
            // Ligne du haut 
            Console.Write("\n\t╔═");
            for (int i = 1; i < colValue; i++)
            {
                Console.Write("══╦═");
            }
            Console.WriteLine("══╗");

            // Millieu 
            for (int row = 0; row < lineValue; row++)
            {
                Console.Write("\t║");
                for (int col = 0; col < colValue; col++)
                {
                    if (gameTable[row, col] == 0)
                    {
                        Console.Write("   ║");
                    }
                    else if (gameTable[row, col] == 1)
                    {
                        Console.ForegroundColor = PlayerColor1;
                        Console.Write(" " + PlayerIcon1 + " ║");
                        Console.ResetColor();
                    }
                    else if (gameTable[row, col] == 2)
                    {
                        Console.ForegroundColor = PlayerColor2;
                        Console.Write(" " + PlayerIcon2 + " ║");
                        Console.ResetColor();
                    }
                }
                Console.WriteLine();
                if (row != lineValue - 1)
                {
                    Console.Write("\t╠═");
                    for (int i = 1; i < colValue; i++)
                    {
                        Console.Write("══╬═");
                    }
                    Console.WriteLine("══╣");
                }
            }

            // Ligne du bas
            Console.Write("\t╚═");
            for (int i = 1; i < colValue; i++)
            {
                Console.Write("══╩═");
            }
            Console.WriteLine("══╝");
        }

        /// <summary>
        /// Méthode qui affiche, si on veut recommencer la partie, en appuyant sur O / N
        /// </summary>
        /// <param name="colValue">Valeur de la colonne </param>
        /// <param name="lineValue">Valeur de la ligne</param>
        static void QuitOrRestart(int colValue, int lineValue)
        {

            // Réinitialise les couleurs de la console
            Console.ResetColor();

            // Positionne le texte à une position
            Console.SetCursorPosition(LEFT, 5 + (lineValue + 1) * 2 + 6);

            // Demande si on veut recommencer ou pas, tout en écoutant la touche sur laquelle il va presser
            Console.Write($"Voulez-vous recommencer ? (o / n) : ");

            // Boucle dans laquelle on peut intéragir pour soit fermer le programme ou recommencer une partie
            do
            {
                var keyInfo = Console.ReadKey();

                // Intéraction avec la touche "O"
                if (keyInfo.Key == ConsoleKey.O)
                {
                    // Clear la console, efface tous les textes
                    Console.Clear();


                    // Met le tour et la couleur au joueur 1
                    turn = 2;
                    SetCharColor(turn);

                    // Recommence la partie avec un break
                    inGame = true;
                    break;


                }
                // Intéraction avec la touche "N"
                else if (keyInfo.Key == ConsoleKey.N)
                {

                    // Message de fin
                    Console.Write("\n\n\tMerci d'avoir utilisé le programme. ");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Appuyez sur une touche pour quitter...");

                    // Attend la pression d'un touche pour quitter
                    Console.ReadKey();

                    // Quitte le programme en mettant un définissant inGame en false et avec un break
                    inGame = false;
                    break;

                }
                // Si il ne met ni "o" ni "n", ca met une erreur
                else if (!(keyInfo.Key == ConsoleKey.O || keyInfo.Key == ConsoleKey.N))
                {
                    string errMessage = "Choix invalide. Veuillez saisir 'o' pour recommencer ou 'n' pour quitter.";


                    Console.SetCursorPosition(LEFT, 5 + (lineValue + 1) * 2 + 8);
                    Console.Write(errMessage);

                    Console.CursorLeft = errMessage.Length + 1;
                    Console.Write("");
                }
            } while (true);
        }


    }
}
